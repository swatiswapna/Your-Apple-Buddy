import SwiftUI
import CoreHaptics

// MARK: - Core Data Models and Types
enum GestureType: String, CaseIterable, Identifiable {
    case twoFingerSwipe = "2-Finger Swipe"
    case threeFingerSwipe = "3-Finger Swipe"
    case dragDrop = "Drag & Drop"
    case rightClick = "Right Click"
    case pinchIn = "Pinch In"
    case pinchOut = "Pinch Out"
    case launchpad = "Launchpad"
    case missionControl = "Mission Control"
    case recents = "Recents"
    case finder = "Finder"
    case controlCenter = "Control Center"
    case notificationCenter = "Notification Center"
    
    var id: String { rawValue }
    
    var baseColor: Color {
        switch self {
        case .twoFingerSwipe: return .blue
        case .threeFingerSwipe: return .green
        case .dragDrop: return .orange
        case .rightClick: return .red
        case .pinchIn: return .teal
        case .pinchOut: return .mint
        case .launchpad: return .pink
        case .missionControl: return .indigo
        case .recents: return .purple
        case .finder: return .blue
        case .controlCenter: return .gray
        case .notificationCenter: return .yellow
        }
    }
    
    var icon: String {
        switch self {
        case .twoFingerSwipe: return "arrow.left.arrow.right"
        case .threeFingerSwipe: return "hand.draw.fill"
        case .dragDrop: return "arrow.up.doc.on.clipboard"
        case .rightClick: return "contextualmenu.and.cursorarrow"
        case .pinchIn: return "minus.magnifyingglass"
        case .pinchOut: return "plus.magnifyingglass"
        case .launchpad: return "square.grid.3x3.fill"
        case .missionControl: return "rectangle.3.group.fill"
        case .recents: return "clock.arrow.circlepath"
        case .finder: return "folder.fill"
        case .controlCenter: return "switch.2"
        case .notificationCenter: return "bell.fill"
        }
    }
    
    var color: LinearGradient {
        switch self {
        case .twoFingerSwipe: return LinearGradient(colors: [.blue, .purple], startPoint: .topLeading, endPoint: .bottomTrailing)
        case .threeFingerSwipe: return LinearGradient(colors: [.green, .mint], startPoint: .topLeading, endPoint: .bottomTrailing)
        case .dragDrop: return LinearGradient(colors: [.orange, .yellow], startPoint: .topLeading, endPoint: .bottomTrailing)
        case .rightClick: return LinearGradient(colors: [.red, .pink], startPoint: .topLeading, endPoint: .bottomTrailing)
        case .pinchIn: return LinearGradient(colors: [.teal, .cyan], startPoint: .topLeading, endPoint: .bottomTrailing)
        case .pinchOut: return LinearGradient(colors: [.mint, .teal], startPoint: .topLeading, endPoint: .bottomTrailing)
        case .launchpad: return LinearGradient(colors: [.pink, .purple], startPoint: .topLeading, endPoint: .bottomTrailing)
        case .missionControl: return LinearGradient(colors: [.indigo, .blue], startPoint: .topLeading, endPoint: .bottomTrailing)
        case .recents: return LinearGradient(colors: [.purple, .indigo], startPoint: .topLeading, endPoint: .bottomTrailing)
        case .finder: return LinearGradient(colors: [.blue, .cyan], startPoint: .topLeading, endPoint: .bottomTrailing)
        case .controlCenter: return LinearGradient(colors: [.gray, .white], startPoint: .topLeading, endPoint: .bottomTrailing)
        case .notificationCenter: return LinearGradient(colors: [.yellow, .orange], startPoint: .topLeading, endPoint: .bottomTrailing)
        }
    }
    
    var shortcut: [String] {
        switch self {
        case .missionControl: return ["⌃", "↑"]
        case .launchpad: return ["⌘", "⌥", "L"]
        case .twoFingerSwipe: return ["⇧", "⌘", "4"]
        case .recents: return ["⌘", "⇧", "O"]
        case .finder: return ["⌘", "N"]
        case .controlCenter: return ["⌘", "⌥", "C"]
        case .notificationCenter: return ["⌘", "⌥", "N"]
        default: return []
        }
    }
    
    var description: String {
        switch self {
        case .twoFingerSwipe: return "Navigate between pages or browse history"
        case .threeFingerSwipe: return "Switch between full-screen apps"
        case .dragDrop: return "Move files and content between locations"
        case .rightClick: return "Access context-specific options"
        case .pinchIn: return "Zoom out or close items"
        case .pinchOut: return "Zoom in or open details"
        case .launchpad: return "Access all your applications"
        case .missionControl: return "View all open windows and spaces"
        case .recents: return "Access recently used files and apps"
        case .finder: return "Open new Finder window"
        case .controlCenter: return "Access quick settings and controls"
        case .notificationCenter: return "View recent notifications"
        }
    }
}

// MARK: - View Model
class GestureMasteryViewModel: ObservableObject {
    @Published var score = 0
    @Published var unlockedGestures: Set<GestureType> = []
    @Published var currentCategory: String = "Navigation"
    private let haptic = HapticManager.shared
    
    func completeGesture(_ gesture: GestureType) {
        haptic.playSuccess()
        withAnimation(.spring(response: 0.5, dampingFraction: 0.7)) {
            score += 50
            unlockedGestures.insert(gesture)
        }
    }
    
    func resetProgress() {
        withAnimation {
            score = 0
            unlockedGestures.removeAll()
        }
    }
}

// MARK: - Haptic Manager
class HapticManager {
    static let shared = HapticManager()
    private var engine: CHHapticEngine?
    
    init() {
        prepareHaptics()
    }
    
    private func prepareHaptics() {
        guard CHHapticEngine.capabilitiesForHardware().supportsHaptics else { return }
        
        do {
            engine = try CHHapticEngine()
            try engine?.start()
        } catch {
            print("Haptic engine error: \(error)")
        }
    }
    
    func playSuccess() {
        guard CHHapticEngine.capabilitiesForHardware().supportsHaptics else { return }
        
        let intensity = CHHapticEventParameter(parameterID: .hapticIntensity, value: 1.0)
        let sharpness = CHHapticEventParameter(parameterID: .hapticSharpness, value: 0.5)
        let event = CHHapticEvent(eventType: .hapticTransient, parameters: [intensity, sharpness], relativeTime: 0)
        
        do {
            let pattern = try CHHapticPattern(events: [event], parameters: [])
            let player = try engine?.makePlayer(with: pattern)
            try player?.start(atTime: 0)
        } catch {
            print("Failed to play haptic: \(error)")
        }
    }
}

// MARK: - Main Views
struct ContentView: View {
    @StateObject private var viewModel = GestureMasteryViewModel()
    @State private var selectedCategory: String? = "Navigation"
    @State private var showSettings = false
    
    var body: some View {
        NavigationSplitView {
            SidebarView(selectedCategory: $selectedCategory)
                .environmentObject(viewModel)
        } detail: {
            NavigationStack {
                GestureCategoryView(category: selectedCategory ?? "Navigation")
                    .environmentObject(viewModel)
            }
        }
        .preferredColorScheme(.dark)
        .sheet(isPresented: $showSettings) {
            SettingsView()
                .environmentObject(viewModel)
        }
    }
}
// MARK: - Navigation Views
    @Binding var selectedCategory: String?
    @EnvironmentObject var viewModel: GestureMasteryViewModel
    let categories = ["Navigation", "Windows", "Zoom", "System", "iOS Features"]
    
    var body: some View {
        List(categories, id: \.self, selection: $selectedCategory) { category in
            NavigationLink(value: category) {
                Label(category, systemImage: iconForCategory(category))
            }
        }
        .navigationTitle("Gestures")
        .toolbar {
            ToolbarItem {
                ScoreBadgeView(score: viewModel.score)
            }
        }
    }
    
struct GestureCategoryView: View {
    let category: String
    @EnvironmentObject var viewModel: GestureMasteryViewModel
    
    var filteredGestures: [GestureType] {
        switch category {
        case "Navigation":
            return [.twoFingerSwipe, .threeFingerSwipe]
        case "Windows":
            return [.dragDrop, .rightClick]
        case "Zoom":
            return [.pinchIn, .pinchOut]
        case "System":
            return [.launchpad, .missionControl, .finder]
        case "iOS Features":
            return [.recents, .controlCenter, .notificationCenter]
        default:
            return []
        }
    }
    
    var body: some View {
        ScrollView {
            LazyVGrid(columns: [
                GridItem(.adaptive(minimum: 300, maximum: 400), spacing: 20)
            ], spacing: 20) {
                ForEach(filteredGestures, id: \.self) { gesture in
                    GestureCardView(gesture: gesture)
                }
            }
            .padding()
        }
        .navigationTitle(category)
    }
}

// MARK: - Enhanced UI Components
struct GestureCardView: View {
    let gesture: GestureType
    @EnvironmentObject var viewModel: GestureMasteryViewModel
    @State private var isHovered = false
    @State private var showSimulation = false
    
    var body: some View {
        VStack(spacing: 0) {
            headerView
            
            if showSimulation && !viewModel.unlockedGestures.contains(gesture) {
                GestureSimulationView(gesture: gesture)
                    .transition(.asymmetric(
                        insertion: .opacity.combined(with: .scale(scale: 0.9)),
                        removal: .opacity
                    )
                                }
                                }
                        .background {
                            RoundedRectangle(cornerRadius: 20)
                                .fill(.ultraThinMaterial)
                                .overlay {
                                    RoundedRectangle(cornerRadius: 20)
                                        .stroke(gesture.color, lineWidth: viewModel.unlockedGestures.contains(gesture) ? 2 : 0)
                                }
                        }
                        .shadow(color: viewModel.unlockedGestures.contains(gesture) ? 
                                gesture.baseColor.opacity(0.3) : 
                                .clear, 
                                radius: 10)
                            .onHover { hovering in
                                withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) {
                                    isHovered = hovering
                                }
                            }
                                }
                                
                                private var headerView: some View {
                        HStack {
                            VStack(alignment: .leading, spacing: 8) {
                                HStack {
                                    Image(systemName: gesture.icon)
                                        .font(.title2)
                                        .foregroundStyle(gesture.color)
                                    
                                    Text(gesture.rawValue)
                                        .font(.headline)
                                        .foregroundStyle(.primary)
                                }
                                
                                if !gesture.shortcut.isEmpty {
                                    HStack(spacing: 6) {
                                        ForEach(gesture.shortcut, id: \.self) { key in
                                            Text(key)
                                                .font(.system(size: 12, weight: .bold, design: .rounded))
                                                .padding(4)
                                                .background(.ultraThickMaterial)
                                                .clipShape(RoundedRectangle(cornerRadius: 4))
                                        }
                                    }
                                }
                            }
                            
                            Spacer()
                            
                            if viewModel.unlockedGestures.contains(gesture) {
                                Image(systemName: "checkmark.circle.fill")
                                    .foregroundColor(.green)
                                    .transition(.scale)
                            } else {
                                Image(systemName: "chevron.right")
                                    .rotationEffect(.degrees(showSimulation ? 90 : 0))
                                    .foregroundColor(.secondary)
                            }
                        }
                        .padding()
                        .contentShape(Rectangle())
                        .onTapGesture {
                            if !viewModel.unlockedGestures.contains(gesture) {
                                withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) {
                                    showSimulation.toggle()
                                }
                            }
                        }
                    }
                                }
}

// MARK: - Gesture Simulations
struct GestureSimulationView: View {
    let gesture: GestureType
    @EnvironmentObject var viewModel: GestureMasteryViewModel
    
    var body: some View {
        ZStack {
            switch gesture {
            case .twoFingerSwipe:
                TwoFingerSwipeSimulation()
            case .threeFingerSwipe:
                ThreeFingerSwipeSimulation()
            case .dragDrop:
                DragDropSimulation()
            case .rightClick:
                RightClickSimulation()
            case .pinchIn:
                PinchSimulation(isPinchIn: true)
            case .pinchOut:
                PinchSimulation(isPinchIn: false)
            case .launchpad:
                LaunchpadSimulation()
            case .missionControl:
                MissionControlSimulation()
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(.ultraThinMaterial)
        .clipShape(RoundedRectangle(cornerRadius: 20))
        .padding(8)
    }
}

struct TwoFingerSwipeSimulation: View {
    @State private var offset: CGFloat = 0
    @State private var phase: SimulationPhase = .ready
    @EnvironmentObject var viewModel: GestureMasteryViewModel
    
    enum SimulationPhase {
        case ready, dragging, success, failed
    }
    
    var body: some View {
        GeometryReader { geometry in
            ZStack {
                HStack(spacing: 30) {
                    ForEach(0..<2, id: \.self) { _ in
                        Circle()
                            .fill(.white.opacity(0.5))
                            .frame(width: 30, height: 30)
                    }
                }
                .offset(x: offset)
                
                if phase == .ready {
                    Text("Swipe with two fingers")
                        .font(.callout)
                        .foregroundStyle(.secondary)
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .contentShape(Rectangle())
            .gesture(
                DragGesture()
                    .onChanged { value in
                        phase = .dragging
                        offset = value.translation.width
                    }
                    .onEnded { value in
                        if abs(value.translation.width) > geometry.size.width * 0.3 {
                            withAnimation(.spring()) {
                                offset = value.translation.width > 0 ? geometry.size.width : -geometry.size.width
                                phase = .success
                            }
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                                viewModel.completeGesture(.twoFingerSwipe)
                            }
                        } else {
                            withAnimation(.spring()) {
                                offset = 0
                                phase = .ready
                            }
                        }
                    }
            )
        }
    }
}

struct ThreeFingerSwipeSimulation: View {
    @State private var offset: CGFloat = 0
    @State private var phase: SimulationPhase = .ready
    @EnvironmentObject var viewModel: GestureMasteryViewModel
    
    enum SimulationPhase {
        case ready, dragging, success, failed
    }
    
    var body: some View {
        GeometryReader { geometry in
            ZStack {
                HStack(spacing: 20) {
                    ForEach(0..<3, id: \.self) { _ in
                        Circle()
                            .fill(.white.opacity(0.5))
                            .frame(width: 25, height: 25)
                    }
                }
                .offset(x: offset)
                
                if phase == .ready {
                    Text("Swipe with three fingers")
                        .font(.callout)
                        .foregroundStyle(.secondary)
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .contentShape(Rectangle())
            .gesture(
                DragGesture()
                    .onChanged { value in
                        phase = .dragging
                        offset = value.translation.width
                    }
                    .onEnded { value in
                        if abs(value.translation.width) > geometry.size.width * 0.3 {
                            withAnimation(.spring()) {
                                offset = value.translation.width > 0 ? geometry.size.width : -geometry.size.width
                                phase = .success
                            }
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                                viewModel.completeGesture(.threeFingerSwipe)
                            }
                        } else {
                            withAnimation(.spring()) {
                                offset = 0
                                phase = .ready
                            }
                        }
                    }
            )
        }
    }
}

struct DragDropSimulation: View {
    @State private var position: CGPoint = .zero
    @State private var isDragging = false
    @State private var isInDropZone = false
    @EnvironmentObject var viewModel: GestureMasteryViewModel
    
    var body: some View {
        GeometryReader { geometry in
            ZStack {
                // Drop zone
                RoundedRectangle(cornerRadius: 15)
                    .stroke(isInDropZone ? Color.green : .white.opacity(0.3), lineWidth: 2)
                    .frame(width: 120, height: 120)
                    .position(x: geometry.size.width * 0.7, y: geometry.size.height * 0.5)
                
                // Draggable item
                Circle()
                    .fill(LinearGradient(colors: [.blue, .purple], startPoint: .top, endPoint: .bottom))
                    .frame(width: 60, height: 60)
                    .position(position)
                    .scaleEffect(isDragging ? 1.1 : 1.0)
                    .gesture(
                        DragGesture()
                            .onChanged { value in
                                isDragging = true
                                position = value.location
                                
                                // Check if in drop zone
                                let dropZoneCenter = CGPoint(x: geometry.size.width * 0.7, y: geometry.size.height * 0.5)
                                let distance = sqrt(
                                    pow(position.x - dropZoneCenter.x, 2) +
                                    pow(position.y - dropZoneCenter.y, 2)
                                )
                                isInDropZone = distance < 60
                            }
                            .onEnded { _ in
                                if isInDropZone {
                                    withAnimation(.spring()) {
                                        position = CGPoint(x: geometry.size.width * 0.7, y: geometry.size.height * 0.5)
                                    }
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                                        viewModel.completeGesture(.dragDrop)
                                    }
                                } else {
                                    withAnimation(.spring()) {
                                        position = CGPoint(x: geometry.size.width * 0.3, y: geometry.size.height * 0.5)
                                        isDragging = false
                                    }
                                }
                                isInDropZone = false
                            }
                    )
                
                if !isDragging {
                    Text("Drag circle to target")
                        .font(.callout)
                        .foregroundStyle(.secondary)
                }
            }
            .onAppear {
                position = CGPoint(x: geometry.size.width * 0.3, y: geometry.size.height * 0.5)
            }
        }
    }
}

struct RightClickSimulation: View {
    @State private var showMenu = false
    @State private var selectedOption: String?
    @EnvironmentObject var viewModel: GestureMasteryViewModel
    
    let menuOptions = ["Copy", "Cut", "Paste", "Delete"]
    
    var body: some View {
        ZStack {
            Circle()
                .stroke(.white.opacity(0.3), lineWidth: 2)
                .frame(width: 80, height: 80)
            
            if showMenu {
                VStack(alignment: .leading, spacing: 4) {
                    ForEach(menuOptions, id: \.self) { option in
                        Button(action: {
                            selectedOption = option
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                                viewModel.completeGesture(.rightClick)
                            }
                        }) {
                            Text(option)
                                .padding(.horizontal, 12)
                                .padding(.vertical, 8)
                                .frame(width: 120, alignment: .leading)
                                .background(selectedOption == option ? Color.blue : Color.clear)
                        }
                        .buttonStyle(.plain)
                    }
                }
                .background(.ultraThickMaterial)
                .cornerRadius(8)
                .offset(x: 60, y: 0)
            }
            
            if !showMenu {
                Text("Right-click or long press")
                    .font(.callout)
                    .foregroundStyle(.secondary)
            }
        }
        .onTapGesture(count: 2) {
            withAnimation(.spring()) {
                showMenu = true
            }
        }
        .gesture(
            LongPressGesture(minimumDuration: 0.5)
                .onEnded { _ in
                    withAnimation(.spring()) {
                        showMenu = true
                    }
                }
        )
    }
}

struct PinchSimulation: View {
    let isPinchIn: Bool
    @State private var scale: CGFloat = 1.0
    @EnvironmentObject var viewModel: GestureMasteryViewModel
    
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 15)
                .stroke(.white.opacity(0.3), lineWidth: 2)
                .frame(width: 200, height: 200)
            
            Image(systemName: isPinchIn ? "minus.magnifyingglass" : "plus.magnifyingglass")
                .font(.system(size: 40))
                .scaleEffect(scale)
            
            if scale == 1.0 {
                Text(isPinchIn ? "Pinch in to zoom out" : "Pinch out to zoom in")
                    .font(.callout)
                    .foregroundStyle(.secondary)
            }
        }
        .gesture(
            MagnificationGesture()
                .onChanged { value in
                    scale = value
                }
                .onEnded { value in
                    let succeeded = isPinchIn ? (value < 0.7) : (value > 1.3)
                    if succeeded {
                        withAnimation(.spring()) {
                            scale = isPinchIn ? 0.5 : 1.5
                        }
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                            viewModel.completeGesture(isPinchIn ? .pinchIn : .pinchOut)
                        }
                    } else {
                        withAnimation(.spring()) {
                            scale = 1.0
                        }
                    }
                }
        )
    }
}

struct LaunchpadSimulation: View {
    @State private var isExpanded = false
    @State private var phase: SimulationPhase = .ready
    @EnvironmentObject var viewModel: GestureMasteryViewModel
    
    enum SimulationPhase {
        case ready, expanding, success
    }
    
    let gridItems = Array(repeating: GridItem(.flexible(), spacing: 20), count: 4)
    
    var body: some View {
        GeometryReader { geometry in
            ZStack {
                LazyVGrid(columns: gridItems, spacing: 20) {
                    ForEach(0..<16) { index in
                        RoundedRectangle(cornerRadius: 12)
                            .fill(Color.blue.opacity(0.5))
                            .frame(width: isExpanded ? 60 : 30, height: isExpanded ? 60 : 30)
                            .offset(y: isExpanded ? 0 : geometry.size.height / 2)
                    }
                }
                .padding()
                
                if phase == .ready {
                    Text("Tap to show Launchpad")
                        .font(.callout)
                        .foregroundStyle(.secondary)
                }
            }
            .onTapGesture {
                guard phase == .ready else { return }
                
                withAnimation(.spring(response: 0.6, dampingFraction: 0.7)) {
                    isExpanded = true
                    phase = .expanding
                }
                
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) {
                    phase = .success
                    viewModel.completeGesture(.launchpad)
                }
            }
        }
    }
}

struct MissionControlSimulation: View {
    @State private var isExpanded = false
    @State private var phase: SimulationPhase = .ready
    @EnvironmentObject var viewModel: GestureMasteryViewModel
    
    enum SimulationPhase {
        case ready, expanding, success
    }
    
    var body: some View {
        GeometryReader { geometry in
            ZStack {
                VStack(spacing: 15) {
                    ForEach(0..<3) { index in
                        RoundedRectangle(cornerRadius: 10)
                            .fill(Color.blue.opacity(0.3))
                            .frame(height: isExpanded ? geometry.size.height / 4 : 20)
                            .offset(y: isExpanded ? CGFloat(index - 1) * 20 : 0)
                    }
                }
                .padding()
                
                if phase == .ready {
                    Text("Swipe up with three fingers")
                        .font(.callout)
                        .foregroundStyle(.secondary)
                }
            }
            .gesture(
                DragGesture()
                    .onChanged { value in
                        guard phase == .ready else { return }
                        if value.translation.height < 0 {
                            withAnimation(.spring()) {
                                isExpanded = true
                                phase = .expanding
                            }
                        }
                    }
                    .onEnded { value in
                        if value.translation.height < -50 && phase == .expanding {
                            phase = .success
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                                viewModel.completeGesture(.missionControl)
                            }
                        } else {
                            withAnimation(.spring()) {
                                isExpanded = false
                                phase = .ready
                            }
                        }
                    }
            )
        }
    }
}

// MARK: - Settings View
struct SettingsView: View {
    @Environment(\.dismiss) var dismiss
    @EnvironmentObject var viewModel: GestureMasteryViewModel
    
    var body: some View {
        NavigationView {
            Form {
                Section("Progress") {
                    Text("Current Score: \(viewModel.score)")
                    Text("Unlocked Gestures: \(viewModel.unlockedGestures.count)/\(GestureType.allCases.count)")
                    
                    Button("Reset Progress", role: .destructive) {
                        viewModel.resetProgress()
                    }
                }
            }
            .navigationTitle("Settings")
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Done") {
                        dismiss()
                    }
                }
            }
        }
    }
}

// MARK: - App Entry
@main
struct GestureMasteryApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
                .frame(minWidth: 1200, minHeight: 800)
        }
    }
}
